declare const chrome: any;

import { io, Socket } from "socket.io-client";

const SERVER_URL = "http://192.168.68.104:4000";
let socket: Socket | null = null;

console.log("[background] Service worker loaded.");

chrome.runtime.onMessage.addListener((message: any, sender: any, sendResponse: (response?: any) => void) => {
  const tabId = sender.tab?.id;

  if (message.type === "INIT_SOCKET") {
    const { role, classId, studentId } = message.payload;
    console.log(`[background] Init socket for role=${role}, classId=${classId}, studentId=${studentId}`);

    if (socket) {
      socket.removeAllListeners();
      socket.close();
    }

    socket = io(SERVER_URL, {
      query: { role, classId, studentId },
      transports: ["websocket"],
      reconnection: true,
    });

    socket.on("connect", () => {
      console.log("[background] Socket connected:", socket?.id);
      if (tabId) {
        chrome.tabs.sendMessage(tabId, { type: "SOCKET_CONNECTED", payload: { id: socket?.id } });
      }
    });

    socket.on("disconnect", (reason) => {
      console.log("[background] Socket disconnected:", reason);
      if (tabId) {
        chrome.tabs.sendMessage(tabId, { type: "SOCKET_DISCONNECTED", payload: { reason } });
      }
    });

    socket.on("backend:message", (data) => {
      if (tabId) {
        chrome.tabs.sendMessage(tabId, { type: "BACKEND_MESSAGE", payload: data });
      }
    });

    socket.on("backend:history", (data) => {
      if (tabId) {
        chrome.tabs.sendMessage(tabId, { type: "BACKEND_HISTORY", payload: data });
      }
    });

    sendResponse({ status: "initializing" });
  }

  if (message.type === "EMIT_EVENT") {
    if (socket && socket.connected) {
      socket.emit(message.payload.event, message.payload.data);
      sendResponse({ status: "sent" });
    } else {
      console.warn("[background] Cannot emit, socket not connected");
      sendResponse({ status: "error", message: "Socket not connected" });
    }
  }

  return true; // Keep message channel open for async response
});
